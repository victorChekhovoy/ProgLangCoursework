#include "value.h"

#ifndef _EVALIF
#define _EVALIF



Value *evalIf(Value *args, Frame *frame);

void displayFrame(Frame *frame);

#endif
