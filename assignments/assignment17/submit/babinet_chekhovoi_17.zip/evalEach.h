#include "value.h"

#ifndef _EVALEACH
#define _EVALEACH

Value *evalEach(Value *argsList, Frame *frame);

#endif
