Our implementation uses a new Value type ERROR_TYPE, defined in value.h. Please use the value.h file included in the submission 
