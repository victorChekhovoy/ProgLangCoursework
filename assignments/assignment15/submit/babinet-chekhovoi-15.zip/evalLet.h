#include "value.h"

#ifndef _EVALLET
#define _EVALLET



Value *evalLet(Value *args, Frame *frame);

#endif
