#ifndef _LOOKUP
#define _LOOKUP

Value *lookUpSymbol(Value *tree, Frame *frame);

#endif
