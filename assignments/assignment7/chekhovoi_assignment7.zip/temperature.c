#include <stdio.h>
#include <stdbool.h>

int main() {
  float temperature_fahrenheint;
  printf("Enter temperature value you want to convert: ");
  scanf("%f", &temperature_fahrenheint);
  if (temperature_fahrenheint < -459.67){
    printf("Invalid temperature!");
  } else{
    float temperature_celcius = (temperature_fahrenheint - 32) / 1.8;
    printf("Converted temperature is %f Celcius\n", temperature_celcius);
  }

  return 0;
}
