/* Hello World in C */

#include <stdio.h>

int main() {
    printf("I AM A C PROGRAMMING LEGEND!!!\n");
}
