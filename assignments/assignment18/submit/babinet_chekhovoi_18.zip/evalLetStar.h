#include "value.h"

#ifndef _EVALLETSTAR
#define _EVALLETSTAR


Value *evalLetStar(Value *args, Frame *frame);

#endif
