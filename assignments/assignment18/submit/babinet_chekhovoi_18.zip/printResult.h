#ifndef _PRINT
#define _PRINT

void printResult(Value *result);

#endif
