#include "value.h"

#ifndef _EVALLETREC
#define _EVALLETREC


Value *evalLetRec(Value *args, Frame *frame);

#endif
